# ProgramadorMetodoGrafico
 Programador lineal y no lineal utilizando el metodo gráfico
